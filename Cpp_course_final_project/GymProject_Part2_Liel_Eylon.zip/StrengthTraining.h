#ifndef __SRTENGTHTRAINING_H
#define __SRTENGTHTRAINING_H

#include "PersonalWorkout.h"

class StrengthTraininig : public PersonalWorkout
{
public:
	static constexpr int NUMBER_OF_PLANS = 3;
	enum class Workoutplan { A, B, C };
	const char WorkoutPlanAsString[NUMBER_OF_PLANS] = { 'A', 'B', 'C' };

	StrengthTraininig(int workoutId, double duration, const char* location, const Date& date, bool withCoach,
		const Member& member, Workoutplan plan, Coach* coach=nullptr);

	StrengthTraininig(const StrengthTraininig& other);
	StrengthTraininig(StrengthTraininig&& other) noexcept;

	const char getWorkOutPlan() const { return WorkoutPlanAsString[(int) this->plan]; }
	void setPlan(const Workoutplan& plan);

	const StrengthTraininig& operator=(const StrengthTraininig& other);

private:
	Workoutplan plan;
	virtual void toOs(ostream& os) const override;
};

#endif 