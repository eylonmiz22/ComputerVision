#include "PersonalWorkout.h"

PersonalWorkout::PersonalWorkout(int workoutId, double duration, const char* location, const Date& date,
	const Member& member, Coach* coach) : Workout(workoutId, duration, location, date, coach)
{ 
	checkCoach(coach);
	setTrainee(member);
}

PersonalWorkout::PersonalWorkout(const PersonalWorkout& other) : Workout(other)
{
	setTrainee(other.trainee);
}

PersonalWorkout::PersonalWorkout(PersonalWorkout&& other) noexcept : Workout(move(other)),
	trainee(move(other.trainee))
{
}

void PersonalWorkout::setTrainee(const Member& trainee) { this->trainee = trainee; }

void PersonalWorkout::checkCoach(const Coach* coach) const
{
	if (coach != nullptr)
	{
		if ((int)Coach::ShiftType::GROUP == (int)coach->getShiftType())
		{
			throw "Incompatible coach for personal workout, type of shift is 'Group'!";
		}
	}
}

bool PersonalWorkout::removeTrainee(const Member& member)
{
	if (this->trainee == member)
	{
		return true;
	}

	return false;
}

const PersonalWorkout& PersonalWorkout::operator=(const PersonalWorkout& other)
{
	Workout::operator=(other);

	setTrainee(other.trainee);
	return *this;
}

void PersonalWorkout::toOs(ostream& os) const 
{ 
	Workout::toOs(os);
	os << endl << "Trainee: " << endl << this->trainee; 
}

