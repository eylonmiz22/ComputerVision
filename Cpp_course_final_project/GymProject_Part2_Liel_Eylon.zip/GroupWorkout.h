#ifndef __GROUPWORKOUT_H_
#define __GROUPWORKOUT_H_

#include "Workout.h"

class GroupWorkout : virtual public Workout
{
protected:
    int numberOfTrainees;
    Member** listOfTrainees;

private:
    void addTrainee(const Member& member);
    void setTrainees(Member** members, int size);

    // Fix the hole in the list, caused the by the removed trainee, by his given index
    void fixList(int index); 

    // Copies a list of trainees of a given GroupWorkout to this GroupWorkout
    void copyList(const GroupWorkout& other); 

    virtual void checkCoach(const Coach* coach) const override;
    void freeTrainees();

protected:
    GroupWorkout(int workoutId, double duration, const char* location, const Date& date,
        Member** members, int size, Coach* coach = nullptr);

    GroupWorkout(const GroupWorkout& other);
    GroupWorkout(GroupWorkout&& other) noexcept;

    const GroupWorkout& operator=(const GroupWorkout& other);
    virtual void toOs(ostream& os) const override;
    virtual bool removeTrainee(const Member& member) override;

public:
    static constexpr int MAXIMUM_NUMBER_OF_TRAINEES = 20;
    static constexpr int MINIMUM_NUMBER_OF_TRAINEES = 2;

    virtual ~GroupWorkout();

    int getNumberOfTrainees() const { return this->numberOfTrainees; }
    const Member& getTraineeByIndex(int index) const;

    const GroupWorkout& operator+=(const Member& other);
    const GroupWorkout& operator-=(const Member& other);

    static int findMemberById(const Member& member, Member** members, int size);
};

#endif