#ifndef __STAFF_H_
#define __STAFF_H_

#include "Person.h"
#include <string.h>
#include <iostream>

using namespace std;

class Staff : virtual public Person 
{
protected:
    int workId;

    Staff(const char* name, int id, const char* phoneNumber, const Date& birthDate, int workId);
    Staff(const Staff& other);
    Staff(Staff&& other) noexcept;

public:
    const int getWorkId() const { return this->workId; }
    void setWorkId(int id);

    operator int() const { return this->workId; }
    bool operator==(const Staff& other) const;
    const Staff& operator=(const Staff& other);
    virtual void toOs(ostream& os) const override { os << ", Worker ID: " << this->workId; }
};

#endif