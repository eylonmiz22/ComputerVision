#include "Pilatis.h"

Pilatis::Pilatis(int workoutId, double duration, const char* location, const Date& date, Member** members, int size,
	Coach* coach, GroupAges groupAge) : 
	GroupWorkout(workoutId, duration, location, date, members, size, coach), 
	Workout(workoutId, duration, location, date, coach)
{
	setGroupAge(groupAge);
}

Pilatis::Pilatis(const Pilatis& other) : GroupWorkout(other), Workout(other), groupAge(GroupAges(0))
{ 
	setGroupAge(other.groupAge);
}

Pilatis::Pilatis(Pilatis&& other) noexcept : GroupWorkout(move(other)), Workout(move(other)),
	groupAge(GroupAges(0))
{
	this->groupAge = other.groupAge;
}

void Pilatis::setGroupAge(const GroupAges& groupAge) { this->groupAge = groupAge; }

const Pilatis& Pilatis::operator=(const Pilatis& other)
{
	GroupWorkout::operator=(other);
	setGroupAge(other.groupAge);

	return *this;
}

void Pilatis::toOs(ostream& os) const
{
	GroupWorkout::toOs(os);
	os << endl << "Group Ages: " << this->groupAgesAsString[(int)groupAge];
}