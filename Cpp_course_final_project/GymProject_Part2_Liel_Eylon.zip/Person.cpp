#include "Person.h"

Person::Person(const char* name, int id, const char* phoneNumber, const Date& birthDate)
{
	setName(name);
	setId(id);
	setPhoneNumber(phoneNumber);
	setBirthDate(birthDate);
}

Person::Person(const Person& other)
{
	*this = other;
}

Person::Person(Person&& other) noexcept : name(nullptr), id(0), phoneNumber(nullptr), birthDate()
{
	this->name = other.name;
	this->id = other.id;
	this->phoneNumber = other.phoneNumber;
	this->birthDate = other.birthDate;

	other.name = nullptr;
	other.phoneNumber = nullptr;
}

Person::~Person()
{
	delete[] this->name;
	delete[] this->phoneNumber;
}

bool digitExist(const char* str)
{ // Checks wheather a given string contains a digit
	int length = static_cast<int>(strlen(str));
	for (int i = 0; i < length; i++)
	{
		if (isdigit(str[i]))
		{
			return true;
		}
	}

	return false;
}

bool isNumber(const char* str)
{ // Checks wheather a given string is a number
	int length = static_cast<int>(strlen(str));
	for (int i = 0; i < length; i++)
	{
		if (!isdigit(str[i]))
		{
			return false;
		}
	}

	return true;
}

void Person::setName(const char* name)
{
	if (digitExist(name) && strlen(name) > MAX_NAME_LENGTH)
	{
		throw "Invalid name inserted!";
	}

	this->name = _strdup(name); 
}

void Person::setId(int id)
{ 
	if (id > MAX_ID_SIZE || id < 1)
	{
		throw "Invalid id inserted!";
	}

	this->id = id; 
}

void Person::setPhoneNumber(const char* phoneNumber) 
{
	if (!isNumber(phoneNumber) && strlen(phoneNumber) > MAX_NAME_LENGTH)
	{
		throw "Phone number must be digits only!";
	}
	
	this->phoneNumber = _strdup(phoneNumber);
}

void Person::setBirthDate(const Date& birthDate) { this->birthDate = birthDate; }


const Person& Person::operator=(const Person& other)
{
	if (this != &other)
	{
		delete[] this->name;
		delete[] this->phoneNumber;

		setName(other.name);
		setId(other.id);
		setPhoneNumber(other.phoneNumber);
		setBirthDate(other.birthDate);
	}

	return *this;
}

bool Person::operator==(const Person& other) const
{
	if (this->id == other.id)
	{
		return true;
	}
	return false;
}

ostream& operator<<(ostream& os, const Person& person)
{
	os << "Name: " << person.name << ", ID: " << person.id << ", Phone Number: " << person.phoneNumber << ", Birth Date: " << person.birthDate;
	person.toOs(os);

	return os;
}

