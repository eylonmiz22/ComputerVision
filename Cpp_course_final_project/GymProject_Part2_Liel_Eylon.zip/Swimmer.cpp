#include "Swimmer.h"

Swimmer::Swimmer(const char* name, int id, const char* phoneNumber, const Date& birthDate,
    const Date& subscriptionDate, double subscriptionLength, int membershipId,
    int numberOfMedals, const Level& level) : 
    Member(name, id, phoneNumber, birthDate, subscriptionDate, subscriptionLength, membershipId),
    Person(name, id, phoneNumber, birthDate)
{
    setNumberOfMedals(numberOfMedals);
    setLevel(level);
}

Swimmer::Swimmer(Swimmer&& other) noexcept : Member(move(other)), Person(move(other)),
    numberOfMedals(0), level(Level(0))
{
    if (this != &other)
    {
        this->numberOfMedals = other.numberOfMedals;
        this->level = other.level;
    }
}

Swimmer::Swimmer(const Swimmer& other) : Member(other), Person(other),
    numberOfMedals(0), level(Level(0))
{
    if (this != &other)
    {
        setNumberOfMedals(other.numberOfMedals);
        setLevel(other.level);
    }
}

void Swimmer::setNumberOfMedals(int numberOfMedals) 
{
    this->numberOfMedals = numberOfMedals;
}

void Swimmer::setLevel(const Level& level) { this->level = level; }

const Swimmer& Swimmer::operator=(const Swimmer& other)
{
    Member::operator=(other);

    setNumberOfMedals(other.numberOfMedals);
    setLevel(other.level);

    return *this;
}

void Swimmer::toOs(ostream& os) const
{
    Member::toOs(os);
    os << endl << "Amount Of Medals: " << this->numberOfMedals << ", Swimmer level: " << this->levelsAsString[(int) this->level];
}
