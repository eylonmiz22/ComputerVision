#ifndef __MEMBER_H_
#define __MEMBER_H_

#include "Person.h"
#include <string.h>
#include <iostream>

using namespace std;

class Member : virtual public Person
{
protected:
    int membershipId;
    double subscriptionLength; // In months
    Date subscriptionDate;

    // Default C'tor for first instantiation, only accessible from it's children
    Member();
    Member(const Member&& other) noexcept;
   
public:
    Member(const char* name, int id, const char* phoneNumber, const Date& birthDate,
        const Date& subscriptionDate, double subscriptionLength, int membershipId);

    Member(const Member& other);
    Member(Member&& other) noexcept;

    const int    getMembershipId() const       { return this->membershipId; }
    const double getSubscriptionLength() const { return this->subscriptionLength; }
    const Date&  getSubscriptionDate() const   { return this->subscriptionDate; }

    void setMembershipId(int membershipId);
    void setSubscriptionLength(double subscriptionLength);
    void setSubscriptionDate(const Date& date);

    const Member& operator=(const Member& other);
    bool operator==(const Member& other) const;
    virtual void toOs(ostream& os) const override;

friend class PersonalWorkout;
friend class PersonalWorkout;
friend class Gym;
};

#endif