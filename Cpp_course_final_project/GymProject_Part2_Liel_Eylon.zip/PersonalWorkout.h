#ifndef __PersonalWorkout_H
#define __PersonalWorkout_H

#include "Workout.h"

class PersonalWorkout : virtual public Workout 
{
protected:
	Member trainee;

	PersonalWorkout(int workoutId, double duration, const char* location, const Date& date,
		const Member& member, Coach* coach = nullptr);

	PersonalWorkout(const PersonalWorkout& other);
	PersonalWorkout(PersonalWorkout&& other) noexcept;

	const PersonalWorkout& operator=(const PersonalWorkout& other);
	virtual void toOs(ostream& os) const override;
	virtual bool removeTrainee(const Member& member) override;

public:
	const Member& getTrainee() const { return this->trainee; }
	void setTrainee(const Member& trainee);

private:
	virtual void checkCoach(const Coach* coach) const override;
};

#endif 
