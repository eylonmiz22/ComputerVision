#include "Coach.h"

Coach::Coach(const char* name, int id, const char* phoneNumber, const Date& birthDate, int workId,
    ShiftType currentShiftType) :
    Staff(name, id, phoneNumber, birthDate, workId), Person(name, id, phoneNumber, birthDate)
{
    setShiftType(currentShiftType);
}

Coach::Coach(Coach&& other) noexcept : Person(move(other)), Staff(move(other))
{
    this->currentShiftType = other.currentShiftType;
}

Coach::Coach(const Coach& other) : Person(other), Staff(other), currentShiftType(ShiftType(0))
{
    if (this != &other)
    {
        setShiftType(other.currentShiftType);
    }
}

void Coach::setShiftType(const ShiftType& currentShiftType) 
{ 
    if ((int) currentShiftType > 2 || (int) currentShiftType < 0)
    {
        throw "Invalid choise!";
    }

    this->currentShiftType = currentShiftType; 
}

const Coach& Coach::operator=(const Coach& other)
{
    Staff::operator=(other);
    setShiftType(other.currentShiftType);

    return *this;
}

void Coach::toOs(ostream& os) const
{
    Staff::toOs(os);
    os << ", Shift Type: " << currentShiftTypeAsString[(int)currentShiftType];
}