#ifndef __GYM_H_
#define __GYM_H_

#include "Member.h"
#include "Administration.h"
#include "Coach.h"
#include "SwimmingTeacher.h"
#include "Pilatis.h"
#include "StrengthTraining.h"

class Gym
{
private:
    static constexpr int MAX_NUMBER_OF_WORKOUTS = 100;
    static constexpr int MAX_NUMBER_OF_MEMBERS = 700;
    static constexpr int MAX_NUMBER_OF_COACHES = 150;
    static constexpr int MAX_NUMBER_OF_ADMINS = 100;

    int numberOfWorkouts;
    int numberOfCoaches;
    int numberOfAdmins;
    int numberOfMembers;

    Workout** allWorkouts;
    Coach** allCoaches;
    Administration** allAdmins;
    Member** allMembers;

    // Fix the hole in the arrays of the gym, caused the by the removed item, by its given index
    void fixStaffArray(int i, Staff** staffArray, int size);
    void fixWorkoutArray(int i);
    void fixMembersArray(int i);

public:
    Gym();
    Gym(const Gym&) = delete;
    ~Gym();

    const Member& getMemberByIndex(int index) const;
    Coach* getCoachByIndex(int index) const;
    const Administration& getAdminByIndex(int index) const;
    const Workout& getWorkoutByIndex(int index) const;

    Member** getAllMembers() const        { return this->allMembers; }
    Coach** getAllCoaches() const         { return this->allCoaches; }
    Administration** getAllAdmins() const { return this->allAdmins; }
    Workout** getAllWorkouts() const      { return this->allWorkouts; };
    const int getNumberOfWorkouts()       { return this->numberOfWorkouts; }
    const int getNumberOfCoaches()        { return this->numberOfCoaches; }
    const int getNumberOfAdmins()         { return this->numberOfAdmins; }
    const int getNumberOfMembers()        { return this->numberOfMembers; }

    void freeAllMembers();
    void freeAllStaff();
    void freeAllWorkouts();

    void addCoach(Coach& coach);
    void addAdmin(Administration& admin);
    void addSwimmingTeacher(SwimmingTeacher& swimmingTeacher);

    void removeCoach(const Coach& coach);
    void removeAdmin(const Administration& admin);

    void addMember(Member& member);
    void removeMember(const Member& member);

    void addWorkout(Workout& workout);
    void addPilatis(Pilatis& pilatis);
    void addStrengthTraining(StrengthTraininig& strengthTraining);
    void removeWorkout(const Workout& workout);

    const Gym& operator+=(Member& other);
    const Gym& operator-=(const Member& other);

    const Gym& operator+=(Administration& other);
    const Gym& operator+=(Coach& other);
    const Gym& operator+=(SwimmingTeacher& other);
    const Gym& operator-=(const Coach& other);
    const Gym& operator-=(const Administration& other);

    const Gym& operator+=(Pilatis& other);
    const Gym& operator+=(StrengthTraininig& other);
    const Gym& operator-=(const Workout& other);

    friend ostream& operator<<(ostream& os, const Gym& gym);

    friend static int GroupWorkout::findMemberById(const Member& member, Member** members, int size);
    static int findCoachById(const Coach& worker, Coach** workers, int size);
    static int findAdminById(const Administration& worker, Administration** workers, int size);
    static int findWorkoutById(const Workout& workout, Workout** workouts, int size);
};

#endif