#include "Member.h"

Member::Member(const char* name, int id, const char* phoneNumber, const Date& birthDate,
    const Date& subscriptionDate, double subscriptionLength, int membershipId) :
    Person(name, id, phoneNumber, birthDate)
{
    setMembershipId(membershipId);
    setSubscriptionLength(subscriptionLength);
    setSubscriptionDate(subscriptionDate);
}

Member::Member() : membershipId(1), subscriptionLength(1), subscriptionDate(Date()) { }

Member::Member(const Member& other) : Person(other), membershipId(0), subscriptionLength(0)
{
    if (this != &other)
    {
        setMembershipId(other.membershipId);
        setSubscriptionLength(other.subscriptionLength);
        setSubscriptionDate(other.subscriptionDate);
    }
}

Member::Member(Member&& other) noexcept : Person(move(other)), 
    membershipId(0), subscriptionLength(0), subscriptionDate()
{    
    if (this != &other)
    {
        this->membershipId = other.membershipId;
        this->subscriptionLength = other.subscriptionLength;
        this->subscriptionDate = other.subscriptionDate;
    }
}

void Member::setMembershipId(int membershipId)
{
    if (membershipId > 9999 || membershipId < 1)
    {
        throw "Invalid membership id inserted!";
    }

    this->membershipId = membershipId;
}

void Member::setSubscriptionLength(double subscriptionLength) { this->subscriptionLength = subscriptionLength; }
void Member::setSubscriptionDate(const Date& date)            { this->subscriptionDate = date; }

const Member& Member::operator=(const Member& other)
{
    Person::operator=(other);

    if (this != &other)
    {
        this->membershipId = other.membershipId;
    }

    return *this;
}

bool Member::operator==(const Member& other) const
{
    if (this->membershipId == other.membershipId || Person::operator==(other))
    {
        return true;
    }

    return false;
}

void Member::toOs(ostream& os) const
{
    os << endl << "MemberShip ID: " << this->membershipId << ", subscription Date: " << this->subscriptionDate 
       << ", subscription Length (in months): " << this->subscriptionLength;
}