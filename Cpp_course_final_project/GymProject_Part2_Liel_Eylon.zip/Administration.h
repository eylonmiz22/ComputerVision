#ifndef __ADMINISTRATION_H_
#define __ADMINISTRATION_H_
#define strdup _strdup

#include <string.h>
#include "Staff.h"

class Administration : public Staff
{
private:
    char* role;
    Administration(const Administration& other);

public:
    static constexpr int MAX_ROLE_LENGTH = 20;

    Administration(const char* name, int id,const char* phoneNumber, const Date& birthDate,
        int workId, const char* role);

    Administration(Administration&& other) noexcept;
    virtual ~Administration();

    const char* getRole() const { return this->role; }
    void setRole(const char* role);

    virtual void toOs(ostream& os) const override;
};


#endif