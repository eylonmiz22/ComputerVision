#include "StrengthTraining.h"

StrengthTraininig::StrengthTraininig(int workoutId, double duration, const char* location, const Date& date,
	bool withCoach, const Member& member, Workoutplan plan, Coach* coach) :
	PersonalWorkout(workoutId, duration, location, date, member, coach),
	Workout(workoutId, duration, location, date, coach)
{
	setPlan(plan);
}

StrengthTraininig::StrengthTraininig(const StrengthTraininig& other) : 
	PersonalWorkout(other), Workout(other), plan(Workoutplan(0))
{
	setPlan(other.plan);
}

StrengthTraininig::StrengthTraininig(StrengthTraininig&& other) noexcept : 
	PersonalWorkout(move(other)), Workout(move(other)), plan(Workoutplan(0))
{
	this->plan = other.plan;
}

void StrengthTraininig::setPlan(const Workoutplan& plan) { this->plan = plan; }

const StrengthTraininig& StrengthTraininig::operator=(const StrengthTraininig& other)
{
	PersonalWorkout::operator=(other);
	setPlan(other.plan);

	return *this;
}

void StrengthTraininig::toOs(ostream& os) const
{
	PersonalWorkout::toOs(os);
	os << endl << "Workout Plan: " << WorkoutPlanAsString[(int)this->plan];
}