#ifndef __PERSON_H_
#define __PERSON_H_

#include "Date.h"
#include <ctype.h>
#include <string.h>
#include <iostream>

using namespace std;

class Person
{
protected:
    char* name;
    char* phoneNumber;
    int id;
    Date birthDate;

    // Default C'tor for first instantiation, only accessible from it's children
    Person(const char* name="", int id=1, const char* phoneNumber="", const Date& birthDate=Date());
    Person(const Person& other);
    Person(Person&& other) noexcept;

public:
    static constexpr int MAX_NAME_LENGTH = 10;
    static constexpr int MAX_PHONE_LENGTH = 10;
    static constexpr int MAX_ID_SIZE = 1000; // For every kind of ID in project

    virtual ~Person();

    const char* getName() const          { return this->name; }
    const int   getId() const            { return this->id; }
    const char*   getPhoneNumber() const { return this->phoneNumber; }
    const Date& getBirthDate() const     { return this->birthDate; }

    void setName(const char* name);
    void setId(int id);
    void setPhoneNumber(const char* phoneNumber);
    void setBirthDate(const Date& birthDate);

    operator int() const { return this->id; }
    const Person& operator=(const Person& other);
    bool operator==(const Person& other) const;
    friend ostream& operator<<(ostream& os, const Person& person);
    virtual void toOs(ostream& os) const { };

    // Checks for the Setters -> documentation in cpp file
    friend bool digitExist(const char* str);
    friend bool isNumber(const char* str);
};

#endif