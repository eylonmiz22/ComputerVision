#include "main.h"

int main()
{
	menu();
	return EXIT_SUCCESS;
}

static void menu()
{
	int choice;
	bool isRunning = true;
	Gym myGym;

	cout << "Welcome to our Gym system :" << endl;

	do
	{
		try
		{
			cout << "----------------------Printing-The-Gym------------------------" << endl;
			cout << myGym;
			cout << "------------------------------Menu----------------------------" << endl;
			cout << "Press 1 to insert new member" << endl;
			cout << "Press 2 to insert new swimmer member" << endl;
			cout << "Press 3 to insert new workout" << endl;
			cout << "Press 4 to insert new staff worker" << endl;
			cout << "Press 5 to delete a member" << endl;
			cout << "Press 6 to delete a workout" << endl;
			cout << "Press 7 to delete a coach" << endl;
			cout << "Press 8 to delete an admin" << endl;
			cout << "Press 9 to search a specific member" << endl;
			cout << "Press 10 to search a specific workout" << endl;
			cout << "Press 11 to search a staff worker" << endl;

			cin >> choice;
			switch (choice)
			{
				case 1:
				{
					Member* tempMember = new Member(getMemberFromUser());
					myGym.addMember(*tempMember);
					break;
				}
				case 2:
				{
					Swimmer* tempSwimmer = new Swimmer(getSwimmerFromUser());
					myGym.addMember(*tempSwimmer);
					break;
				}
				case 3:
				{
					addWorkoutToGym(myGym);
					break;
				}
				case 4:
				{
					addStaffWorkerToGym(myGym);
					break;
				}
				case 5:
				{
					removeMemberFromGym(myGym);
					break;
				}
				case 6:
				{
					removeWorkoutFromGym(myGym);
					break;
				}
				case 7:
				{
					removeCoachFromGym(myGym);
					break;
				}
				case 8:
				{
					removeAdminFromGym(myGym);
					break;
				}
				case 9:
				{
					searchMember(myGym);
					break;
				}
				case 10:
				{
					searchWorkout(myGym);
					break;
				}
				case 11:
				{
					searchStaffMember(myGym);
					break;
				}
				default:
				{
					isRunning = false;
					break;
				}
			}
		}
		catch (const char* errMessage)
		{
			cerr << endl << errMessage << endl << "Please try again!.." << endl;
		}
	} while (isRunning);
}

static void addStaffWorkerToGym(Gym& gym)
{
	int choice;

	cout << "In order to add Administration worker press 1: " << endl
		 << "In order to add Coach worker press 2: " << endl
		 << "In order to add Swimming Teacher press 3: " << endl
		 << "Or press anything else to continue:" << endl;

	cin >> choice;

	switch (choice)
	{
		case 1:
		{
			Administration* tempAdmin = new Administration(getAddministrationFromUser());
			gym.addAdmin(*tempAdmin);
			break;
		}
		case 2:
		{
			Coach* tempCoach = new Coach(getCoachFromUser(2));
			gym.addCoach(*tempCoach);
			break;
		}
		case 3:
		{
			SwimmingTeacher* tempSwimmingTeacher = new SwimmingTeacher(getSwimmingTeacherFromUser());
			gym.addSwimmingTeacher(*tempSwimmingTeacher);
			break;
		}
		default:
		{
			break;
		}
	}
}

static void getPersonFieldsFromUser(char* name, int* id, char* phoneNumber, Date& birthDate)
{
	cout << "Please insert your name (length < " << Person::MAX_NAME_LENGTH << "):" << endl;
	cin >> name;

	cout << "Please insert your ID: " << endl;
	cin >> *id;

	cout << "Please insert your phone number (length < " << Person::MAX_PHONE_LENGTH << "):" << endl;
	cin >> phoneNumber;

	birthDate = getDateFromUser("birth Date");
}

static void getStaffFieldsFromUser(char* name, int* id, char* phoneNumber, Date& birthDate, int* workId)
{
	getPersonFieldsFromUser(name, id, phoneNumber, birthDate);

	cout << "Please insert your work ID: " << endl;
	cin >> *workId;
}

static void getCoachFieldsFromUser(char* name, int* id, char* phoneNumber, Date& birthDate,
	int* workId, Coach::ShiftType currentShiftType, int isGroupWorkout)
{
	int currentShiftAsInteger;

	cout << "Please Insert information about the coach:" << endl << endl;

	getStaffFieldsFromUser(name, id, phoneNumber, birthDate, workId);

	if (isGroupWorkout == 0) // 0 -> Group Workout
	{
		cout << "Please insert your shift type (1-Group, 2-Observer): " << endl;
	}
	else if(isGroupWorkout == 1) // 1 -> Personal workout
	{
		cout << "Please insert your shift type (0-Personal, 2-Observer): " << endl;
	}
	else // Both Personal and Group workouts allowed
	{
		cout << "Please insert your shift type (0-Personal, 1-Group, 2-Observer): " << endl;
	}
		
	cin >> currentShiftAsInteger;
	currentShiftType = (Coach::ShiftType) currentShiftAsInteger;
	
}

static void getMemberFieldsFromUser(char* name, int* id, char* phoneNumber, Date& birthDate,
	Date& subscriptionDate, double* subscriptionLength, int* membershipId)
{
	cout << "Please Insert information about the member:" << endl << endl;

	getPersonFieldsFromUser(name, id, phoneNumber, birthDate);

	subscriptionDate = getDateFromUser("subscription Date");

	cout << "Please insert your subscription Length (in months):" << endl;
	cin >> *subscriptionLength;

	cout << "Please insert your membership ID: " << endl;
	cin >> *membershipId;
}

static void getSwimmerFieldsFromUser(char* name, int* id, char* phoneNumber, Date& birthDate,
	Date& subscriptionDate, double* subscriptionLength, int* membershipId, int* numberOfMedals, Swimmer::Level* level)
{
	cout << "Please Insert information about the swimmer:" << endl << endl;

	getMemberFieldsFromUser(name, id, phoneNumber, birthDate, subscriptionDate, subscriptionLength, membershipId);

	int levelAsInteger;

	cout << "Please insert your number of medals:" << endl;
	cin >> *numberOfMedals;

	cout << "Please insert your level (0-Low, 1-Medium, 2-High, 3-Olympic): " << endl;
	cin >> levelAsInteger;
	*level = (Swimmer::Level) levelAsInteger;
}

static Coach getCoachFromUser(int isGroupWorkout)
{
	char name[Person::MAX_NAME_LENGTH];
	char phoneNumber[Person::MAX_PHONE_LENGTH];
	Date birthDate;
	Coach::ShiftType currentShiftType = Coach::ShiftType(0);
	int id = 0, workId = 0;

	getCoachFieldsFromUser(name, &id, phoneNumber, birthDate, &workId, currentShiftType, isGroupWorkout);

	return Coach(name, id, phoneNumber, birthDate, workId, currentShiftType);
}

static Administration getAddministrationFromUser()
{
	char name[Person::MAX_NAME_LENGTH];
	char phoneNumber[Person::MAX_PHONE_LENGTH];
	char role[Administration::MAX_ROLE_LENGTH];
	Date birthDate;
	int id = 0, workId = 0;

	getStaffFieldsFromUser(name, &id, phoneNumber, birthDate, &workId);

	cout << "Please insert your role (length < " << Administration::MAX_ROLE_LENGTH << "):" << endl;
	cin >> role;

	return Administration(name, id, phoneNumber, birthDate, workId, role);
}

static Member getMemberFromUser()
{
	char name[Person::MAX_NAME_LENGTH];
	char phoneNumber[Person::MAX_PHONE_LENGTH];
	Date birthDate, subscriptionDate;
	int id = 0, memberShipId = 0;
	double subscriptionLength = 0;
	
	getMemberFieldsFromUser(name, &id, phoneNumber, birthDate, subscriptionDate, &subscriptionLength, &memberShipId);

	return Member(name, id, phoneNumber, birthDate, subscriptionDate, subscriptionLength, memberShipId);
}

static Swimmer getSwimmerFromUser()
{
	char name[Person::MAX_NAME_LENGTH];
	char phoneNumber[Person::MAX_PHONE_LENGTH];
	Date birthDate, subscriptionDate;
	int id = 0, memberShipId = 0;
	double subscriptionLength = 0;
	Swimmer::Level level;
	int numberOfMedals = 0;

	getSwimmerFieldsFromUser(name, &id, phoneNumber, birthDate, subscriptionDate, 
		&subscriptionLength, &memberShipId, &numberOfMedals, &level);

	return Swimmer(name, id, phoneNumber, birthDate, subscriptionDate,
		subscriptionLength, memberShipId, numberOfMedals, level);
}

static SwimmingTeacher getSwimmingTeacherFromUser()
{
	int seniority, workId, currentShiftAsInteger;
	Swimmer tempSwimmer = getSwimmerFromUser();
	Coach::ShiftType currentShiftType;

	cout << "Please insert your work ID: " << endl;
	cin >> workId;

	cout << "Please insert your shift type (0-Personal, 1-Group, 2-Observer): " << endl;
	cin >> currentShiftAsInteger;
	currentShiftType = (Coach::ShiftType) currentShiftAsInteger;

	cout << "Please insert your seniority in years, as a teacher:" << endl;
	cin >> seniority;

	return SwimmingTeacher(tempSwimmer.getName(), tempSwimmer.getId(), tempSwimmer.getPhoneNumber(),
		tempSwimmer.getBirthDate(), tempSwimmer.getSubscriptionDate(), tempSwimmer.getSubscriptionLength(),
		tempSwimmer.getMembershipId(), tempSwimmer.getNumberOfMedals(), tempSwimmer.getLevel(),
		workId, currentShiftType, seniority);
}

static const Date getDateFromUser(const char* kindOfDate)
{
	int month, day, year;

	cout << "Please enter your " << kindOfDate << " day: " << endl;
	cin >> day;

	cout << "Please enter your " << kindOfDate << " month: " << endl;
	cin >> month;

	cout << "Please enter your " << kindOfDate << " year: " << endl;
	cin >> year;

	return Date(day, month, year);
}

static void addWorkoutToGym(Gym& gym)
{
	int choice;

	cout << "Please select the type of workout you would like to add: \n" << endl;
	cout << "In order to add Pilatis press 1: " << endl;
	cout << "In order to add Strength Training Workout press 2: " << endl;

	cin >> choice;

	switch (choice)
	{
		case 1:
		{
			Pilatis* tempPilatis = new Pilatis(getPilatisFromUser(gym));
			gym.addPilatis(*tempPilatis);
			break;
		}
		case 2:
		{
			StrengthTraininig* tempStrengthTraininig = new StrengthTraininig(getStrengthTraininigFromUser(gym));
			gym.addStrengthTraining(*tempStrengthTraininig);
			break;
		}
		default:
		{
			throw "Invalid choice!";
			break;
		}
	}
}

static void setMembersFromUser(int size, Gym& gym, Member**& listOfTraineesPointer)
{
	int membershipId, memberIndex;

	if (size < GroupWorkout::MINIMUM_NUMBER_OF_TRAINEES || size > GroupWorkout::MAXIMUM_NUMBER_OF_TRAINEES)
	{
		throw "Invalid number of trainees inserted!";
	}

	listOfTraineesPointer = new Member * [size];
	for (int i = 0; i < size; i++)
	{
		cout << "Insert membership ID of trainee no'" << (i + 1) << ", to attach an existing trainee from the gym:" << endl;
		cin >> membershipId;

		memberIndex = GroupWorkout::findMemberById(Member("name", membershipId, "1111", Date(), Date(), 1, membershipId),
			gym.getAllMembers(), gym.getNumberOfMembers());

		if (memberIndex == -1)
		{
			throw "There is no member with this membership ID in the gym!";
		}

		listOfTraineesPointer[i] = new Member(gym.getMemberByIndex(memberIndex));
	}
}

static void getWorkoutFieldsFromUser(int* workoutId, double* duration, char* location, Date& date, int* workerId)
{
	cout << "Please insert workoutId (length < " << Person::MAX_ID_SIZE << "):" << endl;
	cin >> *workoutId;

	cout << "Please insert the location (length < " << Workout::MAX_LOCATION_LENGTH << "):" << endl;
	cin >> location;

	cout << "Please insert the duration:" << endl;
	cin >> *duration;

	date = getDateFromUser("class Date");

	cout << "Please insert the coach work ID you would like to attach to this workout." << endl
		 << "If there is no coach in this workout, type '-1' instead:" << endl;
	cin >> *workerId;
}

static void getPersonalWorkoutFieldsFromUser(int* workoutId, double* duration, char* location, Date& date, 
	int* memberId, int* workerId)
{
	getWorkoutFieldsFromUser(workoutId, duration, location, date, workerId);

	cout << "Please insert a membership ID of any existing gym member to attach him to this personal workout: " << endl;
	cin >> *memberId;
}

static void getGroupWorkoutFieldsFromUser(int* workoutId, double* duration, char* location, Date& date,
	Member**& members, int* size, int* workerId, Gym& gym)
{
	getWorkoutFieldsFromUser(workoutId, duration, location, date, workerId);

	cout << "Please insert the amount of trainees in the workout (1 < size < " 
		 << GroupWorkout::MAXIMUM_NUMBER_OF_TRAINEES << "):" << endl;
	cin >> *size;

	setMembersFromUser(*size, gym, members);
}

static void getPilatisFieldsFromUser(int* workoutId, double* duration, char* location, Date& date,
	Member**& members, int* size, Pilatis::GroupAges* groupAge, int* workerId, Gym& gym)
{
	int groupAgeAsInteger;

	getGroupWorkoutFieldsFromUser(workoutId, duration, location, date, members, size, workerId, gym);

	cout << "Please insert the group age (0-young-adults, 1-adults, 2-elderies):" << endl;
	cin >> groupAgeAsInteger;
	*groupAge = (Pilatis::GroupAges) groupAgeAsInteger;
}

static void getStrengthTrainingFieldsFromUser(int* workoutId, double* duration, char* location, Date& date,
	StrengthTraininig::Workoutplan* plan, int* memberId, int* workerId)
{
	getPersonalWorkoutFieldsFromUser(workoutId, duration, location, date, memberId, workerId);

	int workoutPlanAsInteger;
	StrengthTraininig::Workoutplan workoutPlan;

	cout << "Please insert the workout plan (0-A, 1-B, 2-C):" << endl;
	cin >> workoutPlanAsInteger;
	workoutPlan = (StrengthTraininig::Workoutplan) workoutPlanAsInteger;
}

static Pilatis getPilatisFromUser(Gym& gym)
{
	int size = 0, workoutId = 0, coachWorkerId, coachIndex;
	double duration = 0;
	char location[Pilatis::MAX_LOCATION_LENGTH];
	Date workoutDate;
	Member** listOfTrainees = nullptr;
	Pilatis::GroupAges groupAge = Pilatis::GroupAges(0);

	getPilatisFieldsFromUser(&workoutId, &duration, location, workoutDate, listOfTrainees,
		&size, &groupAge, &coachWorkerId, gym);

	if (coachWorkerId == -1)
	{
		throw "Group workout has to be with coach!";
	}

	coachIndex = gym.findCoachById(Coach("name", 99, "1111111111", Date(), coachWorkerId,
		Coach::ShiftType(0)), gym.getAllCoaches(), gym.getNumberOfCoaches());

	if (coachIndex == -1)
	{
		throw "There is no such coach in the gym!";
	}
	
	return Pilatis(workoutId, duration, location, workoutDate, listOfTrainees, size, 
		gym.getCoachByIndex(coachIndex), groupAge);
}

static StrengthTraininig getStrengthTraininigFromUser(Gym& gym)
{
	int workoutId = 0, coachIndex, coachWorkerId, memberId, memberIndex;
	double duration = 0;
	char location[Pilatis::MAX_LOCATION_LENGTH];
	Date workoutDate;
	StrengthTraininig::Workoutplan workoutPlan = StrengthTraininig::Workoutplan(0);

	getStrengthTrainingFieldsFromUser(&workoutId, &duration, location, workoutDate, &workoutPlan, &memberId, &coachWorkerId);

	memberIndex = GroupWorkout::findMemberById(Member("name", 3, "phone", Date(), Date(), 1.0, memberId),
		gym.getAllMembers(), gym.getNumberOfMembers());

	if (memberIndex == -1)
	{
		throw "There is no member, with the ID which typed before, in the gym!";
	}

	if (coachWorkerId == -1)
	{
		return StrengthTraininig(11, 11, "eee", workoutDate, true, gym.getMemberByIndex(memberIndex), workoutPlan);
	}

	coachIndex = gym.findCoachById(Coach("name", 99, "1111111111", Date(), coachWorkerId,
		Coach::ShiftType(0)), gym.getAllCoaches(), gym.getNumberOfCoaches());

	if (coachIndex == -1)
	{
		throw "There is no such coach in the gym!";
	}

	return StrengthTraininig(11, 11, "eee", workoutDate, true, gym.getMemberByIndex(memberIndex),
		workoutPlan, gym.getCoachByIndex(coachIndex));
}

static void removeCoachFromGym(Gym& gym)
{
	int id;
	cout << "Please enter coach worker ID of the coach you would like to remove:" << endl;
	cin >> id;

	gym.removeCoach(Coach("name", 99, "1111111111", Date(), id, Coach::ShiftType(0)));
}

static void removeAdminFromGym(Gym& gym)
{
	int id;
	cout << "Please enter the admin worker ID of the admin you would like to remove:" << endl;
	cin >> id;

	gym.removeAdmin(Administration("name", 99, "1111111111", Date(), id, "role"));
}

static void removeMemberFromGym(Gym& gym)
{
	int id;
	cout << "Please enter the membership ID of the member you would like to remove:" << endl;
	cin >> id;

	gym.removeMember(Member("name", 99, "1111111111", Date(), Date(), 40.0, id));
}

static void removeWorkoutFromGym(Gym& gym)
{
	int id;
	cout << "Please enter the workout ID number of the workout you would like to remove:" << endl;
	cin >> id;

	gym.removeWorkout(StrengthTraininig(id, 40.0, "location", Date(), false,
		Member("name", 99, "1111111111", Date(), Date(), 40.0, id), StrengthTraininig::Workoutplan(0)));
}

static void searchMember(Gym& gym)
{
	int id, index;

	cout << "Please enter the membership ID of the member you would like to search: " << endl;
	cin >> id;

	index = GroupWorkout::findMemberById(Member("name", 99, "1111111111", Date(), Date(), 40.0, id), 
		gym.getAllMembers(), gym.getNumberOfMembers());

	if (index == -1)
	{
		cout << "Member does not exist" << endl;
		return;
	}

	cout << "Member is exist:" << endl;
	cout << gym.getMemberByIndex(index) << endl;
}

static void searchCoach(Gym& gym)
{
	int id, index;

	cout << "Please enter coach work ID of the coach you would like to search: " << endl;
	cin >> id;

	index = gym.findCoachById(Coach("name", 99, "1111111111", Date(), id, Coach::ShiftType(0)),
		gym.getAllCoaches(), gym.getNumberOfCoaches());

	if (index == -1)
	{
		throw "Coach to search does not exist";
	}

	cout << "Coach exists:" << endl;
	cout << gym.getCoachByIndex(index) << endl;
}

static void searchAdmin(Gym& gym)
{
	int id, index;

	cout << "Please enter coach work ID of the coach you would like to search: " << endl;
	cin >> id;

	index = gym.findAdminById(Administration("name", 99, "1111111111", Date(), id, "role"),
		gym.getAllAdmins(), gym.getNumberOfAdmins());

	if (index == -1)
	{
		throw "Admin to search does not exist";
	}

	cout << "Admin exists:" << endl;
	cout << gym.getAdminByIndex(index) << endl;
}

static void searchStaffMember(Gym& gym)
{
	int choice;

	cout << "In order to search admin press 1: " << endl
		 << "In order to search coach press 2: " << endl
		 << "Or press anything else to continue:" << endl;

	cin >> choice;

	switch (choice)
	{
		case 1:
		{
			searchAdmin(gym);
			break;
		}
		case 2:
		{
			searchCoach(gym);
			break;
		}
		default:
		{
			break;
		}
	}
}

static void searchWorkout(Gym& gym)
{
	int id, index;

	cout << "Please enter the workout ID number of the workout you would like to search: " << endl;
	cin >> id;

	index = gym.findWorkoutById(StrengthTraininig(id, 40.0, "location", Date(), false,
		Member("name", 99, "1111111111", Date(), Date(), 40.0, id), StrengthTraininig::Workoutplan(0)),
		gym.getAllWorkouts(), gym.getNumberOfWorkouts());

	if (index == -1)
	{
		cout << "Workout does not exist" << endl;
		return;
	}

	cout << "Workout is exist:" << endl;
	cout << gym.getWorkoutByIndex(index) << endl;
}