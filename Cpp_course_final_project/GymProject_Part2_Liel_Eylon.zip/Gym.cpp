#include "Gym.h"

Gym::Gym() : numberOfCoaches(0), numberOfAdmins(0), numberOfMembers(0), numberOfWorkouts(0)
{
	this->allWorkouts = new Workout * [MAX_NUMBER_OF_WORKOUTS];
	this->allCoaches = new Coach * [MAX_NUMBER_OF_COACHES];
	this->allAdmins = new Administration * [MAX_NUMBER_OF_ADMINS];
	this->allMembers = new Member * [MAX_NUMBER_OF_MEMBERS];
}

Gym::~Gym()
{
	freeAllMembers();
	freeAllStaff();
	freeAllWorkouts();
}

const Member& Gym::getMemberByIndex(int index) const
{
	try
	{
		return *this->allMembers[index];
	}
	catch (...)
	{
		throw "There is no member in this given index!";
	}
}

Coach* Gym::getCoachByIndex(int index) const
{
	try
	{
		return this->allCoaches[index];
	}
	catch (...)
	{
		throw "There is no coach in this given index!";
	}
}

const Administration& Gym::getAdminByIndex(int index) const
{
	try
	{
		return *this->allAdmins[index];
	}
	catch (...)
	{
		throw "There is no administration worker in this given index!";
	}
}

const Workout& Gym::getWorkoutByIndex(int index) const
{
	try
	{
		return *this->allWorkouts[index];
	}
	catch (...)
	{
		throw "There is no workout in this given index!";
	}
}

void Gym::freeAllMembers()
{
	delete[] this->allMembers;
}

void Gym::freeAllStaff()
{
	delete[] this->allAdmins;
}

void Gym::freeAllWorkouts()
{
	delete[] this->allWorkouts;
}

void Gym::addCoach(Coach& coach)
{
	if (this->numberOfCoaches == MAX_NUMBER_OF_COACHES)
	{
		throw "The coaches list is full!";
	}
	if (findCoachById(coach, this->allCoaches, this->numberOfCoaches) != -1)
	{
		throw "This coach is already exist!";
	}
	else
	{
		this->allCoaches[this->numberOfCoaches++] = &coach;
	}
}

void Gym::addAdmin(Administration& admin)
{
	if (this->numberOfAdmins == MAX_NUMBER_OF_ADMINS)
	{
		throw "The admins list is full!";
	}
	if (findAdminById(admin, this->allAdmins, this->numberOfAdmins) != -1)
	{
		throw "This admin is already exist!";
	}
	else
	{
		this->allAdmins[this->numberOfAdmins++] = &admin;
	}
}

void Gym::addSwimmingTeacher(SwimmingTeacher& swimmingTeacher)
{
	if (this->numberOfCoaches == MAX_NUMBER_OF_COACHES)
	{
		throw "The coaches list is full!";
	}
	if (findCoachById(swimmingTeacher, this->allCoaches, this->numberOfCoaches) != -1)
	{
		throw "This swimming teacher is already exist!";
	}
	else
	{
		this->allCoaches[this->numberOfCoaches++] = &swimmingTeacher;
	}
}

void Gym::removeCoach(const Coach& coach)
{
	int index = findCoachById(coach, this->allCoaches, this->numberOfCoaches);
	if (index == -1)
	{
		throw "This coach does not exist!";
	}

	int tempNumberOfWorkouts = this->numberOfWorkouts;
	for (int i = 0; i < tempNumberOfWorkouts; i++)
	{
		// Removes all workouts that related to the coach to remove
		if (this->allWorkouts[i]->getCoach() != nullptr && *this->allWorkouts[i]->getCoach() == coach)
		{
			removeWorkout(*this->allWorkouts[i]);
		}
	}

	fixStaffArray(index, (Staff**)this->allCoaches, this->numberOfCoaches);
	this->numberOfCoaches--;
}

void Gym::removeAdmin(const Administration& admin)
{
	int index = findAdminById(admin, this->allAdmins, this->numberOfAdmins);
	if (index == -1)
	{
		throw "This admin does not exist!";
	}

	fixStaffArray(index, (Staff**)this->allAdmins, this->numberOfAdmins);
	this->numberOfAdmins--;
}

void Gym::addMember(Member& member)
{
	if (this->numberOfMembers == MAX_NUMBER_OF_MEMBERS)
	{
		throw "The member list is full!";
	}
	if (GroupWorkout::findMemberById(member, this->allMembers, this->numberOfMembers) != -1)
	{
		throw "This member is already exist!";
	}
	else
	{
		this->allMembers[this->numberOfMembers++] = &member;
	}
}

void Gym::removeMember(const Member& member)
{
	bool isEmptyWorkout = false;
	int index = GroupWorkout::findMemberById(member, this->allMembers, this->numberOfMembers);
	int tempNumberOfWorkouts = this->numberOfWorkouts;

	if (index == -1)
	{
		throw "This member does not exist!";
	}

	for (int i = 0; i < tempNumberOfWorkouts; i++)
	{
		isEmptyWorkout = this->allWorkouts[i]->removeTrainee(member);

		// Removes all workouts which have no members after removing the given member
		if (isEmptyWorkout)
		{
			removeWorkout(*this->allWorkouts[i]);
		}
	}

	fixMembersArray(index);
}

void Gym::addWorkout(Workout& workout)
{
	if (this->numberOfWorkouts == MAX_NUMBER_OF_WORKOUTS)
	{
		throw "The workout list is full!";
	}
	if (findWorkoutById(workout, this->allWorkouts, this->numberOfWorkouts) != -1)
	{
		throw "This workout is already exist!";
	}
	else
	{
		this->allWorkouts[this->numberOfWorkouts++] = &workout;
	}
}

void Gym::addPilatis(Pilatis& pilatis)
{
	if (this->numberOfWorkouts == MAX_NUMBER_OF_WORKOUTS)
	{
		throw "The workout list is full!";
	}
	if (findWorkoutById(pilatis, this->allWorkouts, this->numberOfWorkouts) != -1)
	{
		throw "This workout is already exist!";
	}
	else
	{
		this->allWorkouts[this->numberOfWorkouts++] = &pilatis;
	}
}

void Gym::addStrengthTraining(StrengthTraininig& strengthTraining)
{
	if (this->numberOfWorkouts == MAX_NUMBER_OF_WORKOUTS)
	{
		throw "The workout list is full!";
	}
	if (findWorkoutById(strengthTraining, this->allWorkouts, this->numberOfWorkouts) != -1)
	{
		throw "This workout is already exist!";
	}
	else
	{
		this->allWorkouts[this->numberOfWorkouts++] = &strengthTraining;
	}
}

void Gym::removeWorkout(const Workout& workout)
{
	int index = findWorkoutById(workout, this->allWorkouts, this->numberOfWorkouts);
	if (index == -1)
	{
		throw "This workout does not exist!";
	}

	fixWorkoutArray(index);
}

void Gym::fixStaffArray(int i, Staff** staffArray, int size)
{
	for (int begin = i; begin < size; begin++)
	{
		staffArray[begin] = staffArray[begin + 1];
	}
	staffArray[size - 1] = nullptr;
}

void Gym::fixMembersArray(int i)
{
	for (int begin = i; begin < this->numberOfMembers-1; begin++)
	{
		this->allMembers[begin] = this->allMembers[begin + 1];
	}
	this->allMembers[this->numberOfMembers--] = nullptr;
}

void Gym::fixWorkoutArray(int i)
{
	for (int begin = i; begin < this->numberOfWorkouts-1; begin++)
	{
		this->allWorkouts[begin] = this->allWorkouts[begin + 1];
	}
	this->allWorkouts[this->numberOfWorkouts--] = nullptr;
}

int Gym::findWorkoutById(const Workout& workout, Workout** workouts, int size)
{
	for (int i = 0; i < size; i++)
	{
		if (*workouts[i] == workout)
		{
			return i;
		}
	}

	return -1;
}

int Gym::findCoachById(const Coach& worker, Coach** workers, int size)
{
	for (int i = 0; i < size; i++)
	{
		if (*workers[i] == worker)
		{
			return i;
		}
	}

	return -1;
}

int Gym::findAdminById(const Administration& worker, Administration** workers, int size)
{
	for (int i = 0; i < size; i++)
	{
		if (*workers[i] == worker)
		{
			return i;
		}
	}

	return -1;
}

const Gym& Gym::operator+=(Member& other)
{
	addMember(other);
	return *this;
}

const Gym& Gym::operator-=(const Member& other)
{
	removeMember(other);
	return *this;
}

const Gym& Gym::operator+=(Administration& other)
{
	addAdmin(other);
	return *this;
}

const Gym& Gym::operator+=(Coach& other)
{
	addCoach(other);
	return *this;
}

const Gym& Gym::operator+=(SwimmingTeacher& other)
{
	addSwimmingTeacher(other);
	return *this;
}

const Gym& Gym::operator-=(const Coach& other)
{
	removeCoach(other);
	return *this;
}

const Gym& Gym::operator-=(const Administration& other)
{
	removeAdmin(other);
	return *this;
}

const Gym& Gym::operator+=(StrengthTraininig& other)
{
	addStrengthTraining(other);
	return *this;
}

const Gym& Gym::operator+=(Pilatis& other)
{
	addPilatis(other);
	return *this;
}

const Gym& Gym::operator-=(const Workout& other)
{
	removeWorkout(other);
	return *this;
}

ostream& operator<<(ostream& os, const Gym& gym)
{
	os << "Number of workouts: " << gym.numberOfWorkouts << endl;
	for (int i = 0; i < gym.numberOfWorkouts; i++)
	{
		os << "Workout no'" << (i + 1) << ":" << endl;
		os << *gym.allWorkouts[i] << endl << endl;
	}
	
	os << endl << "Number of staff members: " << gym.numberOfCoaches + gym.numberOfAdmins << endl;

	os << endl << "Number of coaches: " << gym.numberOfCoaches << endl;
	for (int i = 0; i < gym.numberOfCoaches; i++)
	{
		os << "Coach no'" << (i + 1) << ":" << endl;
		os << *gym.allCoaches[i] << endl << endl;
	}

	os << endl << "Number of admins: " << gym.numberOfAdmins << endl;
	for (int i = 0; i < gym.numberOfAdmins; i++)
	{
		os << "Admin no'" << (i + 1) << ":" << endl;
		os << *gym.allAdmins[i] << endl << endl;
	}

	os << endl << "Number of members: " << gym.numberOfMembers << endl;
	for (int i = 0; i < gym.numberOfMembers; i++)
	{
		os << "Member no'" << (i + 1) << ":" << endl;
		os << *gym.allMembers[i] << endl << endl;
	}

	return os;
}