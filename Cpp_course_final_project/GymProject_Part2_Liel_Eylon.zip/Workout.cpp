#include "Workout.h"

Workout::Workout(int workoutId, double duration, const char* location, const Date& date, Coach* coach)
{ 
    setWorkoutId(workoutId);
    setDuration(duration);
    setLocation(location);
    setDate(date);
    setCoach(coach);
}

Workout::Workout(const Workout& other)
{
    *this = other;
}

Workout::Workout(Workout&& other) noexcept : workoutId(0), duration(0), location(nullptr), date(), coach(nullptr)
{
    this->workoutId = other.workoutId;
    this->duration = other.duration;
    this->location = other.location;
    this->date = other.date;
    this->coach = other.coach;

    other.location = nullptr;
    other.coach = nullptr;
}

Workout::~Workout()
{
    delete[] this->location;
}

void Workout::setWorkoutId(int workoutId)
{
    if (workoutId > Person::MAX_ID_SIZE || workoutId < 1)
    {
        throw "Invalid workout id inserted!";
    }

    this->workoutId = workoutId;
}

void Workout::setDuration(double duration)      { this->duration = duration; }
void Workout::setCoach(Coach* coach)            { this->coach = coach; }
void Workout::setDate(const Date& date)         { this->date = date; }

void Workout::setLocation(const char* location)
{
    if (strlen(location) > MAX_LOCATION_LENGTH)
    {
        throw "Invalid location inserted!";
    }

    this->location = _strdup(location);
}

const Workout& Workout::operator=(const Workout& other)
{
    if (this != &other)
    {
        delete this->location;
        delete this->coach;

        setWorkoutId(other.workoutId);
        setDuration(other.duration);
        setLocation(other.location);
        setDate(other.date);
        setCoach(other.coach);
    }

    return *this;
}

bool Workout::operator==(const Workout& other) const
{
    if (this->workoutId == other.workoutId || this == &other)
    {
        return true;
    }

    return false;

}
ostream& operator<<(ostream& os, const Workout& workout)
{
    os << "Workout ID: " << workout.workoutId << ", Duration: " << workout.duration << ", Location: " << workout.location
       << ", Date: " << workout.date << ", Workout's Coach: ";
    
    if (workout.coach == nullptr)
    {
        os << "No coach for this personal workout";
    }
    else
    {
        os << endl << *workout.coach;
    }
    
    workout.toOs(os);
    return os;
}