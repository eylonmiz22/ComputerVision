#include "SwimmingTeacher.h"

SwimmingTeacher::SwimmingTeacher(const char* name, int id, const char* phoneNumber, const Date& birthDate,
	const Date& subscriptionDate, double subscriptionLength, int membershipId,
	int numberOfMedals, const Level& level, int workId, const ShiftType& currentShiftType, int seniority) :
	Swimmer(name, id, phoneNumber, birthDate, subscriptionDate, subscriptionLength, membershipId,
		numberOfMedals, level),
	Coach(name, id, phoneNumber, birthDate, workId, currentShiftType),
	Member(name, id, phoneNumber, birthDate, subscriptionDate, subscriptionLength, membershipId),
	Staff(name, id, phoneNumber, birthDate, workId), Person(name, id, phoneNumber, birthDate)
{
	setSeniority(seniority);
}

SwimmingTeacher::SwimmingTeacher(SwimmingTeacher&& other) noexcept : Coach(move(other)), Swimmer(move(other)),
	Member(move(other)), Staff(move(other)), Person(move(other)), seniority(0)
{
	this->seniority = other.seniority;
}

SwimmingTeacher::SwimmingTeacher(const SwimmingTeacher& other) : Coach(other), Swimmer(other),
	Member(other), Staff(other), Person(other), seniority(0)
{
	if (this != &other)
	{
		setSeniority(other.seniority);
	}
}

void SwimmingTeacher::setSeniority(int seniority) { this->seniority = seniority; }

const SwimmingTeacher& SwimmingTeacher::operator=(const SwimmingTeacher& other)
{
	Swimmer::operator=(other);
	setSeniority(other.seniority);

	return *this;
}

void SwimmingTeacher::toOs(ostream& os) const
{
	Swimmer::toOs(os);
	os << ", ";
	Coach::toOs(os);
	os << ", Seniority: " << this->seniority;
}

