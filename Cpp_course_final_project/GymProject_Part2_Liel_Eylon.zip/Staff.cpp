#include "Staff.h"

Staff::Staff(const char* name, int id, const char* phoneNumber, const Date& birthDate, int workId) :
	Person(name, id, phoneNumber, birthDate)
{
	setWorkId(workId);
}

Staff::Staff(const Staff& other) : Person(other)
{
	if (this != &other)
	{
		setWorkId(other.workId);
	}
}

Staff::Staff(Staff&& other) noexcept : Person(move(other))
{
	this->workId = other.workId;
}

void Staff::setWorkId(int workId) 
{
	if (workId > 999 || workId < 1)
	{
		throw "Invalid work id inserted!";
	}

	this->workId = workId; 
}

bool Staff::operator==(const Staff& other) const
{
	if (this->workId == other.workId || Person::operator==(other))
	{
		return true;
	}

	return false;
}

const Staff& Staff::operator=(const Staff& other)
{
	Person::operator=(other);
	this->workId = other.workId;

	return *this;
}