#ifndef __SWIMMINGTEACHER_H
#define __SWIMMINGTEACHER_H

#include "Swimmer.h"
#include "Coach.h"

class SwimmingTeacher : public Swimmer, public Coach
{
private:
	int seniority; // In years

	SwimmingTeacher(const SwimmingTeacher& other);
	const SwimmingTeacher& operator=(const SwimmingTeacher& other);
	virtual void toOs(ostream& os) const override;

public:
	SwimmingTeacher(const char* name, int id, const char* phoneNumber, const Date& birthDate,
		const Date& subscriptionDate, double subscriptionLength, int membershipId,
		int numberOfMedals, const Level& level, int workId, const ShiftType& currentShiftType, int seniority);

	SwimmingTeacher(SwimmingTeacher&& other) noexcept;

	const int getSeniority() const { return this->seniority; }
	void setSeniority(int seniority);
	
friend class Gym;
};

#endif