#ifndef __COACH_H_
#define __COACH_H_

#include "Staff.h"

class Coach : virtual public Staff
{
public:
    static constexpr int NUMBER_OF_SHIFT_TYPES = 3;
    enum class ShiftType { PERSONAL, GROUP, OBSERVER };
    const char* currentShiftTypeAsString[NUMBER_OF_SHIFT_TYPES] = { "Personal", "Group", "Observer" };

    Coach(const char* name, int id, const char* phoneNumber, const Date& birthDate, int workId,
        ShiftType currentShiftType);

    Coach(Coach&& other) noexcept;

    const char* getShiftTypeAsString() const { return currentShiftTypeAsString[(int) currentShiftType]; }
    const ShiftType getShiftType() const { return this->currentShiftType; }
    void setShiftType(const ShiftType& currentShiftType);

    const Coach& operator=(const Coach& other);
    virtual void toOs(ostream& os) const override;

friend class Gym;

protected:    
    ShiftType currentShiftType;
    Coach(const Coach& other);
};

#endif