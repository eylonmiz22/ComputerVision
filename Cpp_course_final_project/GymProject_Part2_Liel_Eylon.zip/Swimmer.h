#ifndef __SWIMMER_H_
#define __SWIMMER_H_

#include <string.h>
#include "Member.h"

class Swimmer : virtual public Member
{
public:
    static constexpr int NUMBER_OF_LEVELS = 4;
    enum class Level { LOW, MEDIUM, HIGH, OLYMPIC };
    const char* levelsAsString[NUMBER_OF_LEVELS] = { "Low", "Medium", "High", "Olympic" };

    Swimmer(const char* name, int id, const char* phoneNumber, const Date& birthDate,
        const Date& subscriptionDate, double subscriptionLength, int membershipId,
        int numberOfMedals, const Level& level);

    Swimmer(const Swimmer& other);
    Swimmer(Swimmer&& other) noexcept;

    const int getNumberOfMedals() const { return this->numberOfMedals; }
    const Level& getLevel() const { return this->level; }

    void setNumberOfMedals(int numberOfMedals);
    void setLevel(const Level& level);

    const Swimmer& operator=(const Swimmer& other);

protected:
    int numberOfMedals;
    Level level;

    virtual void toOs(ostream& os) const override;
};


#endif