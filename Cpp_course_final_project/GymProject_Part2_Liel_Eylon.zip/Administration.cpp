#include "Administration.h"

Administration::Administration(const char* name, int id, const char* phoneNumber, const Date& birthDate,
	int workId, const char* role) : 
	Staff(name, id, phoneNumber, birthDate, workId), Person(name, id, phoneNumber, birthDate)
{ 
	setRole(role);
}

Administration::Administration(Administration&& other) noexcept : Staff(move(other)), Person(move(other))
{
	this->role = other.role;
	other.role = nullptr;
}

Administration::Administration(const Administration& other) : Staff(other), Person(other), role(nullptr)
{
	if (this != &other)
	{
		setRole(other.role);
	}
}

Administration::~Administration()
{
	delete this->role;
}

void Administration::setRole(const char* role) { this->role = strdup(role); }

void Administration::toOs(ostream& os) const
{
	Staff::toOs(os);
	os << ", Role: " << this->role; 
}
