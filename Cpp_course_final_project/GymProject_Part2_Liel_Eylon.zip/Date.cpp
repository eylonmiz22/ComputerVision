#include "Date.h"

Date::Date(int day, int month, int year)
{
	setDay(day);
	setMonth(month);
	setYear(year);
}

Date::Date(Date&& other) noexcept
{
	*this = other;
}

void Date::setDay(int day)
{
	if (day < 1 || day > 31)
	{
		throw "Invalid day inserted!";
	}
	this->day = day;
}

void Date::setMonth(int month)
{
	if (month < 1 || month > 12)
	{
		throw "Invalid month inserted!";
	}
	this->month = month;
}

void Date::setYear(int year)
{
	if (year < 1900 || year > 9999)
	{
		throw "Invalid year inserted!";
	}
	this->year = year;
}

void Date::operator=(const Date& other)
{
	if (this != &other)
	{
		setDay(other.day);
		setMonth(other.month);
		setYear(other.year);
	}
}

bool Date::operator==(const Date& other) const
{
	if (this->day == other.day && this->month == other.month && this->year == other.year)
	{
		return true;
	}

	return false;
}

ostream& operator<<(ostream& os, const Date& date)
{
	os << date.day << "." << date.month << "." << date.year;

	return os;
}

