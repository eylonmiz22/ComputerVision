#ifndef __HELPFUNCTIONS_H_
#define __HELPFUNCTIONS_H_

#include <string.h>
#include <ctype.h>
#include <iostream>

using namespace std;

bool isNumber(const char* str)
{ // Checks wheather a given string is a number // ����� �����
	int length = strlen(str);
	for (int i = 0; i < length; i++)
	{
		if (!isdigit(str[i]))
		{
			return false;
		}
	}
	
	return true;
}

#endif