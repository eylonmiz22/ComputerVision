#ifndef __DATE_H_
#define __DATE_H_

#include <iostream>

using namespace std;

class Date
{
private:
    int day;
    int month;
    int year;

public:
    Date(int day=1, int month=1, int year=1948);
    Date(Date&& other) noexcept;

    const int getDay() const    { return this->day; }
    const int getMonth() const  { return this->month; }
    const int getYear() const   { return this->year; }

    void setDay(int day=1);
    void setMonth(int month=1);
    void setYear(int year=1948);

    bool operator==(const Date& other) const;
    void operator=(const Date& other);
    friend ostream& operator<<(ostream& os, const Date& date);
};

#endif