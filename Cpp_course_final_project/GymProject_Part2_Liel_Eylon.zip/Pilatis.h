#ifndef __PILATIS_H_
#define __PILATIS_H_

#include "GroupWorkout.h"
#include <iostream>

using namespace std;

class Pilatis : public GroupWorkout
{
public:
    static constexpr int MAX_LOCATION_LENGTH = 20;
    static constexpr int NUMBER_OF_GROUP_AGES = 3;

    enum class GroupAges { YOUNG_ADULTS, ADULTS, ELDERIES };
    const char* groupAgesAsString[NUMBER_OF_GROUP_AGES] = { "Young Adults", "Adults", "Elderies" };

    Pilatis(int workoutId, double duration, const char* location, const Date& date, Member** members, int size,
        Coach* coach, GroupAges groupAge);

    Pilatis(const Pilatis& other);
    Pilatis(Pilatis&& other) noexcept;

    const char* getGroupAge() const { return this->groupAgesAsString[(int)groupAge]; }
    void setGroupAge(const GroupAges& groupAge);

    const Pilatis& operator=(const Pilatis& other);

private:
    GroupAges groupAge;

    virtual void toOs(ostream& os) const override;
};


#endif