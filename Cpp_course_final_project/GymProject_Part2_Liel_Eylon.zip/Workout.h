#ifndef __WORKOUT_H_
#define __WORKOUT_H_

#include "Coach.h"
#include "Member.h"
#include <string.h>
#include <iostream>

using namespace std;

class Workout
{
protected:
    int workoutId;
    double duration;
    Date date;
    char* location;
    Coach* coach;

    Workout(int workoutId, double duration, const char* location, const Date& date, Coach* coach = nullptr);
    Workout(const Workout& other);
    Workout(Workout&& other) noexcept;

    const Workout& operator=(const Workout& other);
    virtual void toOs(ostream& os) const { }

    // Deletes a member from the workout, and after removing ->
    // Returns true if deleting the workout is neccessary, as it has no trainees from the gym that attached to it
    virtual bool removeTrainee(const Member& member) = 0;

public:
    static constexpr int MAX_LOCATION_LENGTH = 10;

    virtual ~Workout();

    const int getWorkoutId() const    { return this->workoutId; }
    const double getDuration() const  { return this->duration; }
    const char*  getLocation() const  { return this->location; }
    const Date&  getDate() const      { return this->date; }
    const Coach* getCoach() const     { return this->coach; }

    void setWorkoutId(int workoutId);
    void setDuration(double duration);
    void setLocation(const char* location);
    void setDate(const Date& date);
    void setCoach(Coach* coach);

    bool operator==(const Workout& other) const;
    friend ostream& operator<<(ostream& os, const Workout& workout);

private:
    // Checks if the given coach is valid for this workout demands
    virtual void checkCoach(const Coach* coach) const { }

friend class Gym;
};

#endif