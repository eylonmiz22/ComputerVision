#ifndef __MAIN_H_
#define __MAIN_H_

#include "Gym.h"

static void menu();

static void getPersonFieldsFromUser(char* name, int* id, char* phoneNumber, Date& birthDate);

static void getStaffFieldsFromUser(char* name, int* id, char* phoneNumber, Date& birthDate, int* workId);

static void getCoachFieldsFromUser(char* name, int* id, char* phoneNumber, Date& birthDate,
	int* workId, Coach::ShiftType currentShiftType, int isGroupWorkout);

static void getMemberFieldsFromUser(char* name, int* id, char* phoneNumber, Date& birthDate,
	Date& subscriptionDate, double* subscriptionLength, int* membershipId);

static void getSwimmerFieldsFromUser(char* name, int* id, char* phoneNumber, Date& birthDate,
	Date& subscriptionDate, double* subscriptionLength, int* membershipId, int* numberOfMedals, Swimmer::Level* level);

static void getWorkoutFieldsFromUser(int* workoutId, double* duration, char* location, Date& date, int* workerId);

static void getPersonalWorkoutFieldsFromUser(int* workoutId, double* duration, char* location, Date& date,
	int* memberId, int* workerId);

static void getGroupWorkoutFieldsFromUser(int* workoutId, double* duration, char* location, Date& date,
	Member**& members, int* size, int* workerId, Gym& gym);

static void getPilatisFieldsFromUser(int* workoutId, double* duration, char* location, Date& date,
	Member**& members, int* size, Pilatis::GroupAges* groupAge, int* workerId, Gym& gym);

static void getStrengthTrainingFieldsFromUser(int* workoutId, double* duration, char* location, Date& date,
	StrengthTraininig::Workoutplan* plan, int* memberId, int* workerId);


static Coach getCoachFromUser(int isGroupWorkout);
static Administration getAddministrationFromUser();
static Member getMemberFromUser();
static Swimmer getSwimmerFromUser();
static SwimmingTeacher getSwimmingTeacherFromUser();

static const Date getDateFromUser(const char* kindOfDate);
static void setMembersFromUser(int size, Gym& gym, Member**& listOfTraineesPointer);

static Pilatis getPilatisFromUser(Gym& gym);
static StrengthTraininig getStrengthTraininigFromUser(Gym& gym);

static void addStaffWorkerToGym(Gym& gym);
static void addWorkoutToGym(Gym& gym);

// Remove / Search functions by ID, as operator== operates
static void removeCoachFromGym(Gym& gym);
static void removeAdminFromGym(Gym& gym);
static void removeMemberFromGym(Gym& gym);
static void removeWorkoutFromGym(Gym& gym);

static void searchMember(Gym& gym);
static void searchCoach(Gym& gym);
static void searchAdmin(Gym& gym);
static void searchWorkout(Gym& gym);

static void searchStaffMember(Gym& gym);

#endif