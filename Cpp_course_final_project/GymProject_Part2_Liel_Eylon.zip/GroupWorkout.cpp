#include "GroupWorkout.h"

GroupWorkout::GroupWorkout(int workoutId, double duration, const char* location, const Date& date,
	Member** members, int size, Coach* coach) : Workout(workoutId, duration, location, date, coach)
{
	checkCoach(coach);
	this->numberOfTrainees = 0;
	this->listOfTrainees = new Member * [MAXIMUM_NUMBER_OF_TRAINEES];
	setTrainees(members, size);
}

GroupWorkout::GroupWorkout(const GroupWorkout& other) : Workout(other)
{
	copyList(other);
}

GroupWorkout::GroupWorkout(GroupWorkout&& other) noexcept : Workout(move(other)),
	listOfTrainees(nullptr), numberOfTrainees(0)
{
	this->listOfTrainees = other.listOfTrainees;
	this->numberOfTrainees = other.numberOfTrainees;

	for (int i = 0; i < other.numberOfTrainees; i++)
	{
		other.listOfTrainees[i] = nullptr;
	}
	other.listOfTrainees = nullptr;
}

GroupWorkout::~GroupWorkout()
{
	freeTrainees();
}

const Member& GroupWorkout::getTraineeByIndex(int index) const
{
	try
	{
		return *this->listOfTrainees[index];
	}
	catch (...)
	{
		throw "There is no trainee in this given index!";
	}
}

void GroupWorkout::addTrainee(const Member& member)
{
	if (this->numberOfTrainees > MAXIMUM_NUMBER_OF_TRAINEES)
	{
		throw "There is not enough place in this group!";
	}
	if (findMemberById(member, this->listOfTrainees, this->numberOfTrainees) != -1)
	{
		throw "Given member is already exists in the list!";
	}
	
	Member* tempMember = new Member(member);
	this->listOfTrainees[this->numberOfTrainees++] = tempMember;
}

bool GroupWorkout::removeTrainee(const Member& member)
{
	int indexOfRemovingItem = findMemberById(member, this->listOfTrainees, this->numberOfTrainees);

	if (indexOfRemovingItem != -1)
	{
		fixList(indexOfRemovingItem);
	}
	if (this->numberOfTrainees < MINIMUM_NUMBER_OF_TRAINEES)
	{
		return true;
	}

	return false;
}

void GroupWorkout::setTrainees(Member** members, int size)
{
	// Checks for a valid size
	if (size < MINIMUM_NUMBER_OF_TRAINEES)
	{
		throw "Not enough trainees for a group! ( < 2) ";
	}
	else if (size > MAXIMUM_NUMBER_OF_TRAINEES)
	{
		throw "Too many trainees for a group! ( > 20) ";
	}
	else if (members == nullptr)
	{
		throw "List of trainees cannot be empty or null, but between 2-20 trainees!";
	}

	for (int i = 0; i < size; i++)
	{
		addTrainee(*members[i]);
	}
}

void GroupWorkout::fixList(int index)
{
	for (int i = index; i < this->numberOfTrainees - 1; i++)
	{
		this->listOfTrainees[i] = this->listOfTrainees[i + 1];
	}

	this->listOfTrainees[this->numberOfTrainees--] = nullptr;
}

void GroupWorkout::freeTrainees()
{
	for (int i = 0; i < this->numberOfTrainees; i++)
	{
		delete this->listOfTrainees[i];
	}

	delete[] this->listOfTrainees;
}

const GroupWorkout& GroupWorkout::operator+=(const Member& other)
{
	addTrainee(other);
	return *this;
}

const GroupWorkout& GroupWorkout::operator-=(const Member& other)
{
	removeTrainee(other);
	return *this;
}

void GroupWorkout::toOs(ostream& os) const
{
	Workout::toOs(os);

	os << endl << "Number of trainees: " << this->numberOfTrainees << ", Trainees:";
	for (int i = 0; i < this->numberOfTrainees; i++)
	{
		os << endl << "Trainee no'" << (i + 1) << ": " << *this->listOfTrainees[i];
	}
}

const GroupWorkout& GroupWorkout::operator=(const GroupWorkout& other)
{
	Workout::operator=(other);
	copyList(other);

	return *this;
}

void GroupWorkout::copyList(const GroupWorkout& other)
{
	this->numberOfTrainees = other.numberOfTrainees;
	for (int i = 0; i < this->numberOfTrainees; i++)
	{
		*this->listOfTrainees[i] = *other.listOfTrainees[i];
	}
}

int GroupWorkout::findMemberById(const Member& member, Member** members, int size)
{
	for (int i = 0; i < size; i++)
	{
		if (*members[i] == member || members[i] == &member)
		{
			return i;
		}
	}

	return -1;
}

void GroupWorkout::checkCoach(const Coach* coach) const
{
	if (coach == nullptr)
	{
		throw "Invalid coach for group workout - should not point to nullptr!";
	}
	else if ((int) coach->getShiftTypeAsString() == 0)
	{
		throw "Incompatible coach for group workout - type of shift is 'Personal'!";
	}
}

