Eylon Mizrahi - 206125411
Daniel Ivkovich - 316421262

/* read the makefile to learn how to run the program */
