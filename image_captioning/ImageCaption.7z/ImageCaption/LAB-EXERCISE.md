# Image Captioning - LAB 3

### 1. Data Exploration - read the dataset and show some examples - dataloader
* Download data from [here](https://www.kaggle.com/dataset/e1cd22253a9b23b073794872bf565648ddbe4f17e7fa9e74766ad3707141adeb)
* Show an image and its caption.
* We wont build our own dataloader since it involves with text processing.
### 2. Model building - model.py
* Build an Encoder (Takes a image and output the extracted features)
    * Choose a backbone and code the forward pass.
* Build a Decoder(Takes the features and the captions to produce a caption prediction).
* Build a Model which combines the Encoder and Decoder.
    * Code the forward pass + inference (not the same thing).

### 3. Training - train.py
* Make sure you are able to reproduce your results by setting seed etc..
* Choose the right hyper parameters for this problem.
* Choose optimizer.
* Make the training loop.
* Make a validation loop.
    * Show relevant loss, metrics (BLEU) and graphs.
### 4. Evaluation
* Show the results:
    * Show 10 correct predictions.
    * Show 10 bad predictions.


### 5. Guidelines
* This work can be done by groups of 2.
* Code must be **readable!!**.
* Write the python code according to [PEP-8 guidelines](https://www.python.org/dev/peps/pep-0008/).
* The **submission** must include the python files, a notebook which runs the written code and a summary which includes results/graphs and explanations.
* Submissions that don't follow the above guidelines wont be accepted.