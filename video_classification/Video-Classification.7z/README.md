# Lab 5

## Basic Video Classification.

### Intro: in the following lab we will train a video classifier using three methods explained in class.
We would like to classify an action from a single frame.

## Tasks:
* [Download](https://drive.google.com/file/d/1Ld6GAnwm9HmhTA9op42kgS76DWyBNlKR/view) the dataset and explore it
* Write a simple CNN network from scratch without using any pretrained networks and train the model to classify actions.

* Now, use a Pretrained model to train the model and compare the results with the other model you trained from sratch. show, graphs and explain what you see.

* Using pre-trained network with chopped head + 1-2 FCN/MLP train the dataset and inference using:
  1. Majority Vote
  2. Probability averaging


* Compare the results between your choices and explain what you got.



# The code template is yours to change it is not suppose to work in its initial state.