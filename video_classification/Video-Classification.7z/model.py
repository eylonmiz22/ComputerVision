import torch
import torch.nn as nn
import torch.nn.functional as F


class SimpleCNN(nn.Module):
    def __init__(self, classes: list):
        super(SimpleCNN, self).__init__()


    def forward(self, x):

        bs, _, _, _ = x.shape

        x = F.adaptive_avg_pool2d(x, 1).reshape(bs, -1)

        return x