import torch
import argparse
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
#import joblib
import albumentations
import torch.optim as optim
import os
#import cnn_models
import matplotlib.pyplot as plt
import time
import pandas as pd
plt.style.use('ggplot')
from sklearn.preprocessing import LabelBinarizer
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm
from PIL import Image
from utils import data_prepare
from dataloader import ImageDataset
from model import SimpleCNN
    # training function
def train(model, train_dataloader, optimizer, criterion,  device, train_data):
    print('Training')
    model.train()
    train_running_loss = 0.0
    train_running_correct = 0
    for i, data in tqdm(enumerate(train_dataloader), total=int(len(train_data)/train_dataloader.batch_size)):
        data, target = data[0].to(device), data[1].to(device)
        optimizer.zero_grad()
        outputs = model(data)
        loss = criterion(outputs, target)
        train_running_loss += loss.item()
        _, preds = torch.max(outputs.data, 1)
        train_running_correct += (preds == target).sum().item()
        loss.backward()
        optimizer.step()
        
    train_loss = train_running_loss/len(train_dataloader.dataset)
    train_accuracy = 100. * train_running_correct/len(train_dataloader.dataset)
    
    print(f"Train Loss: {train_loss:.4f}, Train Acc: {train_accuracy:.2f}")
    
    return train_loss, train_accuracy

def validate(model, test_dataloader, criterion, device, test_data):
    print('Validating')
    model.eval()
    val_running_loss = 0.0
    val_running_correct = 0
    with torch.no_grad():
        for i, data in tqdm(enumerate(test_dataloader), total=int(len(test_data)/test_dataloader.batch_size)):
            data, target = data[0].to(device), data[1].to(device)
            outputs = model(data)
            loss = criterion(outputs, target)
            
            val_running_loss += loss.item()
            _, preds = torch.max(outputs.data, 1)
            val_running_correct += (preds == target).sum().item()
        
        val_loss = val_running_loss/len(test_dataloader.dataset)
        val_accuracy = 100. * val_running_correct/len(test_dataloader.dataset)
        print(f'Val Loss: {val_loss:.4f}, Val Acc: {val_accuracy:.2f}')
        
        return val_loss, val_accuracy


def main():
    root_dir = "data/"
    classes = data_prepare(root_dir)

    # learning_parameters 
    lr = 1e-3
    batch_size = 32
    epochs = 50
    device = 'cuda:0'
    print(f"Computation device: {device}\n")

    # read the data.csv file and get the image paths and labels
    df = pd.read_csv(f'{root_dir}data.csv')
    X = df.image_path.values # image paths
    y = df.target.values # targets
    (xtrain, xtest, ytrain, ytest) = train_test_split(X, y,
        test_size=0.10, random_state=42)
    print(f"Training instances: {len(xtrain)}")
    print(f"Validation instances: {len(xtest)}")


    train_data = ImageDataset(xtrain, ytrain, tfms=1)
    test_data = ImageDataset(xtest, ytest, tfms=0)
    # dataloaders
    trainloader = DataLoader(train_data, batch_size=batch_size, shuffle=True)
    testloader = DataLoader(test_data, batch_size=batch_size, shuffle=False)

    model = SimpleCNN(classes).to(device)
    print(model)
    # total parameters and trainable parameters
    total_params = sum(p.numel() for p in model.parameters())
    print(f"{total_params:,} total parameters.")
    total_trainable_params = sum(
        p.numel() for p in model.parameters() if p.requires_grad)
    print(f"{total_trainable_params:,} training parameters.")

    # optimizer
    optimizer = optim.Adam(model.parameters(), lr=lr)
    # loss function
    criterion = nn.CrossEntropyLoss()


    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau( 
        optimizer,
        mode='min',
        patience=5,
        factor=0.5,
        min_lr=1e-6,
        verbose=True
    )
    train_loss , train_accuracy = [], []
    val_loss , val_accuracy = [], []
    for e in epochs:

        train_epoch_loss, train_epoch_accuracy = train(model, trainloader, optimizer, criterion,
                                                    device, train_data)
        val_epoch_loss, val_epoch_accuracy = validate(model, testloader, criterion, device, test_data)
        train_loss.append(train_epoch_loss)
        train_accuracy.append(train_epoch_accuracy)
        val_loss.append(val_epoch_loss)
        val_accuracy.append(val_epoch_accuracy)
        scheduler.step(val_epoch_loss)
        break

    
if __name__ == "__main__":
    main()