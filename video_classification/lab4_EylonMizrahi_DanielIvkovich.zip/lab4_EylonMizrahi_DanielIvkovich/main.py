import torch
import argparse
import torch.nn as nn
import torch.nn.functional as F
import torchvision
import numpy as np
#import joblib
import albumentations
import torch.optim as optim
import os
import sys
#import cnn_models
import matplotlib.pyplot as plt
import time
import pandas as pd
plt.style.use('ggplot')
from sklearn.preprocessing import LabelBinarizer
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm
from PIL import Image
from utils import data_prepare
from dataloader import ImageDataset
from model import ConvNet, ConvolutionBackbone


root_dir = '/content/gdrive/MyDrive/Vision2/lab4/data/'
folder_weights_path = '/content/gdrive/MyDrive/Vision2/lab4/models'
device = 'cuda:0'
num_classes = 6
save_epoch = 5


"""
Model1 Definition:
"""

# Backnone input: (16,3,224,224) --> output: (16,3,512,8,8)  
backbone1 = ConvolutionBackbone(3, [[8,16], [32,64], [128,256], [512]],
                                [[3,5], [3,5], [3,5], [5]], [[1,1], [1,1], [1,1], [1]],
                                [3,3,3,3], [2,2,2,2], norm='bn',
                                pool_type_lst=['max','max','max','avg'])

flatten1 = nn.Flatten(1, 3)
fc_lst1 = [nn.Linear(512*8*8, 512*8*8 // 8),
          nn.Linear(512*8*8 // 8, 512),
          nn.Linear(512, num_classes)]

model1 = ConvNet(backbone1, fc_lst1,
  flatten=flatten1, softmax_flag=False).to(device);

"""
Model2 Definition:
"""

backbone2 = torchvision.models.resnet50(pretrained=True)
backbone2 = torch.nn.Sequential(*(list(backbone2.children())[:-1]))

flatten2 = nn.Flatten(1, 3)
fc_lst2 = [nn.Linear(in_features=2048, out_features=1024, bias=True),
          nn.Linear(in_features=1024, out_features=512, bias=True),
          nn.Linear(in_features=512, out_features=6, bias=True)]

model2 = ConvNet(backbone2, fc_lst2, flatten2).to(device)

# training function
def train(model, train_dataloader, optimizer, criterion, device, train_data):
    print('Training')
    model.train()
    train_running_loss = 0.0
    train_running_correct = 0
    for i, data in tqdm(enumerate(train_dataloader), total=int(len(train_data)/train_dataloader.batch_size)):
        data, target = data[0].to(device), data[1].to(device)
        optimizer.zero_grad()
        outputs = model(data)
        loss = criterion(outputs, target)
        train_running_loss += loss.item()
        _, preds = torch.max(outputs.data, 1)
        train_running_correct += (preds == target).sum().item()
        loss.backward()
        optimizer.step()
        
    train_loss = train_running_loss/len(train_dataloader.dataset)
    train_accuracy = 100. * train_running_correct/len(train_dataloader.dataset)
    
    print(f"Train Loss: {train_loss:.4f}, Train Acc: {train_accuracy:.2f}")
    
    return train_loss, train_accuracy

def validate(model, test_dataloader, criterion, device, test_data):
    print('Validating')
    model.eval()
    val_running_loss = 0.0
    val_running_correct = 0
    with torch.no_grad():
        for i, data in tqdm(enumerate(test_dataloader), total=int(len(test_data)/test_dataloader.batch_size)):
            data, target = data[0].to(device), data[1].to(device)
            outputs = model(data)
            loss = criterion(outputs, target)
            
            val_running_loss += loss.item()
            _, preds = torch.max(outputs.data, 1)
            val_running_correct += (preds == target).sum().item()
        
        val_loss = val_running_loss/len(test_dataloader.dataset)
        val_accuracy = 100. * val_running_correct/len(test_dataloader.dataset)
        print(f'Val Loss: {val_loss:.4f}, Val Acc: {val_accuracy:.2f}')
        
        return val_loss, val_accuracy

def validate_ensemble(models, test_dataloader, device, test_data, method):
    print('Validating Ensemble of Models')   
    val_running_correct = 0

    with torch.no_grad():
        for i, data in tqdm(enumerate(test_dataloader), total=int(len(test_data)/test_dataloader.batch_size)):
            data, target = data[0].to(device), data[1].to(device)
            outputs_lst = list()

            for i, m in enumerate(models):
                m.eval()
                outputs = F.log_softmax(m(data), 1) # (batch_size, num_classes)
                outputs_lst.append(outputs)

            stacked_outputs = torch.stack(outputs_lst, 1)

            if method == 'avg':
                outputs = torch.mean(stacked_outputs, 1)
                _, preds = torch.max(outputs.data, 1)
            elif method == 'majority_vote':
                _, preds_per_model = torch.max(stacked_outputs.data, 2)
                preds = torch.tensor([max(models_preds.tolist(), key = models_preds.tolist().count) for models_preds in preds_per_model]).to(device)
            
            val_running_correct += (preds == target).sum().item()
            val_accuracy = val_running_correct/len(test_dataloader.dataset)
    
    return val_accuracy
    
def create_dataloaders():
    global root_dir, device

    print(f"Extracting data from {root_dir}\n")
    data_prepare(root_dir)

    batch_size = 32
    print(f"Computation device: {device}\n")

    # read the data.csv file and get the image paths and labels
    df = pd.read_csv(f'{root_dir}data.csv')
    X = df.image_path.values # image paths
    y = df.target.values # targets
    (xtrain, xtest, ytrain, ytest) = train_test_split(X, y,
        test_size=0.10, random_state=42)
    print(f"Training instances: {len(xtrain)}")
    print(f"Validation instances: {len(xtest)}")


    train_data = ImageDataset(xtrain, ytrain, tfms=1)
    test_data = ImageDataset(xtest, ytest, tfms=0)

    # dataloaders
    trainloader = DataLoader(train_data, batch_size=batch_size, shuffle=True)
    testloader = DataLoader(test_data, batch_size=batch_size, shuffle=False)

    return trainloader, testloader, train_data, test_data

def main_train(model, model_name):
    global folder_weights_path, save_epoch, root_dir, device

    trainloader, testloader, train_data, test_data = create_dataloaders()

    # learning_parameters 
    lr = 1e-5
    epochs = 16

    print(model)
    # total parameters and trainable parameters
    total_params = sum(p.numel() for p in model.parameters())
    print(f"{total_params:,} total parameters.")
    total_trainable_params = sum(
        p.numel() for p in model.parameters() if p.requires_grad)
    print(f"{total_trainable_params:,} training parameters.")

    # optimizer
    optimizer = optim.Adam(model.parameters(), lr=lr)
    # loss function
    criterion = nn.CrossEntropyLoss()

    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, epochs)

    train_loss , train_accuracy = [], []
    val_loss , val_accuracy = [], []
    for e in range(epochs):
        print(f"epoch number {e}:")
        train_epoch_loss, train_epoch_accuracy = train(model, trainloader, optimizer, criterion,
                                                    device, train_data)
        val_epoch_loss, val_epoch_accuracy = validate(model, testloader, criterion, device, test_data)
        train_loss.append(train_epoch_loss)
        train_accuracy.append(train_epoch_accuracy)
        val_loss.append(val_epoch_loss)
        val_accuracy.append(val_epoch_accuracy)
        scheduler.step(val_epoch_loss)
        
        if e % save_epoch == 0 and e > 0:
            if not os.path.exists(folder_weights_path):
                os.makedirs(folder_weights_path)
            torch.save(model.state_dict(), f"{folder_weights_path}/{model_name}_e{e}.model")

def main_val(model_paths):
    global model1, model2

    # Load models
    print("Loading the first model")
    model1.load_state_dict(torch.load(model_paths[0]))
    print("Done")

    print("Loading the second model")
    model2.load_state_dict(torch.load(model_paths[1]))
    print("Done")

    # Create the dataloaders
    _, testloader, _, test_data = create_dataloaders()

    criterion = nn.CrossEntropyLoss()

    # Validating both of the models
    print("\nFirst model:")
    val_epoch_loss1, val_epoch_accuracy1 = validate(model1, testloader, criterion, device, test_data)
    print("\nSecond model:")
    val_epoch_loss2, val_epoch_accuracy2 = validate(model2, testloader, criterion, device, test_data)

    ensemble = [model1, model2]

    # Validating the ensemble of models using probability averaging
    print('\n')
    ensemble_acc1 = validate_ensemble(ensemble, testloader, device, test_data, 'avg')
    print(f'\nEnsemble Validation Accuracy using probability averaging: {ensemble_acc1:.2f}')

    # Validating the ensemble of models using majority vote
    ensemble_acc2 = validate_ensemble(ensemble, testloader, device, test_data, 'majority_vote')
    print(f'\nEnsemble Validation Accuracy using majority vote method: {ensemble_acc2:.2f}')


if __name__ == "__main__":
    if len(sys.argv) > 1:
        main_val(sys.argv[1:3])
    else:
        # main_train(model1, 'video_classifier1')
        main_train(model2, 'video_classifier2')