import torch
import torch.nn as nn
import torch.nn.functional as F


"""
Model Wrappers' Definitions
"""

class Conv2dBlock(nn.Module):
    def __init__(self, in_dim, out_dims, conv_ks_lst, conv_st_lst, pool_ks=0,
                 pool_st=0, conv_padding=0, pool_padding=0, norm='none',
                 activation='relu', conv_pad_type='none',
                 pool_pad_type='none', pool_type='none', use_bias=True, num_convs=2):
      
        super(Conv2dBlock, self).__init__()
        self.use_bias = use_bias
        self.conv_pad, self.pool_pad, self.pool = None, None, None
        self.norm, self.activation = None, None

        # initialize convolution padding
        if conv_pad_type == 'reflect':
            self.conv_pad = nn.ReflectionPad2d(conv_padding)
        elif conv_pad_type == 'replicate':
            self.conv_pad = nn.ReplicationPad2d(conv_padding)
        elif conv_pad_type == 'zero':
            self.conv_pad = nn.ZeroPad2d(conv_padding)
        elif conv_pad_type == 'none':
            self.conv_pad = None
        else:
            assert 0, "Unsupported padding type: {}".format(conv_pad_type)

        # initialize pooling
        if pool_st > 0 and pool_ks > 0:
            # initialize pooling padding
            if pool_pad_type == 'reflect':
                self.pool_pad = nn.ReflectionPad2d(pool_padding)
            elif pool_pad_type == 'replicate':
                self.pool_pad = nn.ReplicationPad2d(pool_padding)
            elif pool_pad_type == 'zero':
                self.pool_pad = nn.ZeroPad2d(pool_padding)
            elif pool_pad_type == 'none':
                self.pool_pad = None
            else:
                assert 0, "Unsupported padding type: {}".format(pool_pad_type)

            # pooling layer
            if pool_type == 'avg':
                self.pool = nn.AvgPool2d(pool_ks, (pool_st, pool_st))
            elif pool_type == 'max':
                self.pool = nn.MaxPool2d(pool_ks, (pool_st, pool_st))
            elif pool_type == 'none':
                self.pool = None
            else:
                assert 0, "Unsupported pooling type: {}".format(pool_pad_type)

        # initialize normalization
        norm_dim = out_dims[-1]
        if norm == 'bn':
            self.norm = nn.BatchNorm2d(norm_dim)
        elif norm == 'in':
            self.norm = nn.InstanceNorm2d(norm_dim)
        elif norm == 'adain':
            self.norm = AdaptiveInstanceNorm2d(norm_dim)
        elif norm == 'none':
            self.norm = None
        else:
            assert 0, "Unsupported normalization: {}".format(norm)

        # initialize activation
        if activation == 'relu':
            self.activation = nn.ReLU(inplace=False)
        elif activation == 'lrelu':
            self.activation = nn.LeakyReLU(0.2, inplace=False)
        elif activation == 'tanh':
            self.activation = nn.Tanh()
        elif activation == 'none':
            self.activation = None
        else:
            assert 0, "Unsupported activation: {}".format(activation)

        self.conv_lst = list()
        for dim, ks, st in zip(out_dims, conv_ks_lst, conv_st_lst):
            self.conv_lst.append(nn.Conv2d(in_dim, dim, ks, st, bias=self.use_bias))
            in_dim = dim
        self.conv_lst = nn.Sequential(*self.conv_lst)
            

    def forward(self, x):
        for conv in self.conv_lst:
            if self.conv_pad:
                x = self.conv_pad(x) 
            x = conv(x)

        if self.norm:
            x = self.norm(x)       

        if self.activation:
            x = self.activation(x)

        if self.pool:
            if self.pool_pad:
                x = self.pool_pad(x)
            x = self.pool(x)

        return x


class ConvolutionBackbone(nn.Module):
    def __init__(self, in_channels, out_channels_lst,
                 block_ks_lst, block_st_lst, pool_ks_lst=[], pool_st_lst=[], conv_pad_lst=[], 
                 pool_pad_lst=[], norm='none', activation='relu', 
                 conv_pad_type_lst=[], pool_pad_type_lst=[],
                 pool_type_lst=[], use_bias=True, num_convs_per_block=[]):

        super(ConvolutionBackbone, self).__init__()

        # Fix number of convolution layers per block if necessary
        if len(num_convs_per_block) == 0:
            num_convs_per_block = [2]*len(out_channels_lst)

        # Fix convolution padding inputs if necessary
        if len(conv_pad_lst)==0 or len(conv_pad_type_lst)==0:
            conv_pad_lst = [0]*len(out_channels_lst)
            conv_pad_type_lst = ['none']*len(out_channels_lst)

        # Fix pooling inputs if necessary
        if len(pool_ks_lst)==0 or len(pool_st_lst)==0:
            pool_ks_lst, pool_st_lst, pool_pad_lst = [[0]*len(out_channels_lst)]*3
            pool_pad_type_lst, pool_type_lst = [['none']*len(out_channels_lst)]*2
        elif len(pool_pad_lst)==0 or len(pool_pad_type_lst)==0 or len(pool_type_lst)==0:
            pool_pad_lst = [0]*len(out_channels_lst)
            pool_pad_type_lst = ['none']*len(out_channels_lst)

        self.convblock_lst = list()
        for out_channels, conv_ks_lst, conv_st_lst, pool_ks, pool_st, conv_pad, conv_pad_type, pool_pad, pool_pad_type, pool_type, convs_num in zip(out_channels_lst,
        block_ks_lst, block_st_lst, pool_ks_lst, pool_st_lst, conv_pad_lst, conv_pad_type_lst, pool_pad_lst, pool_pad_type_lst, pool_type_lst, num_convs_per_block):
            self.convblock_lst.append(Conv2dBlock(in_channels, out_channels, conv_ks_lst,
                                      conv_st_lst, pool_ks, pool_st, conv_pad_lst,
                                      pool_pad, norm, activation, conv_pad_type,
                                      pool_pad_type, pool_type, use_bias, convs_num))
            
            in_channels = out_channels[-1]

        self.convblock_lst = nn.Sequential(*self.convblock_lst)


    def forward(self, x):
        return self.convblock_lst(x)



class ConvNet(nn.Module):
    def __init__(self, conv_model, fc_tail_lst=[],
                 flatten=None, softmax_flag=True):
        """
        conv_model:   A convolutional model or a backbone
        fc_tail_lst:  Fully connected layers as list
        flatten:      flatten layer if necessary
        softmax_flag: Determines whether to use softmax on the output or not
        """

        super(ConvNet, self).__init__()

        self.conv_model = conv_model
        self.flatten = flatten
        self.fc_tail, self.conv_head = None, None

        if len(fc_tail_lst) > 0:
            self.fc_tail = nn.Sequential(*fc_tail_lst)

        self.softmax_flag = softmax_flag
        
    def forward(self, x):
        x = self.conv_model(x)

        if self.flatten is not None:
            x = F.relu(self.flatten(x))

        if self.fc_tail is not None:
            x = self.fc_tail(x)

        if self.softmax_flag:
            x = F.log_softmax(x, 1)

        return x


class ConvLstm(nn.Module):
    """
    LSTM Classifier to train on time sequence dataset,
    for example: Video Classification
    """

    def __init__(self, out_channels, backbone, fc_lst=[], flatten=None, embed_size=1024, hidden_size=256, num_layers=1, dropout=0, bidirectional=False):
        super(ConvLstm, self).__init__()
        self.conv_encoder = ConvNet(backbone, fc_lst, flatten)
        self.lstm = nn.LSTM(input_size=embed_size, hidden_size=hidden_size, num_layers=num_layers, dropout=dropout, bidirectional=bidirectional)
        lstm_out_size = hidden_size*2 if bidirectional else hidden_size
        self.fc = nn.Linear(lstm_out_size, out_channels)
       
    def forward(self, x):
        # Extract h_0, c_0 from the first timestamp
        x_t = self.conv_encoder(x[:,0,:,:,:])
        output, (h_t, c_t) = self.lstm(x_t.unsqueeze(0))

        for t in range(1, x.size(1)): # Exclude the first timestamp
            x_t = self.conv_encoder(x[:,t,:,:,:])  
            output, (h_t, c_t) = self.lstm(x_t.unsqueeze(0), (h_t, c_t))

        return self.fc(output[-1, :, :])