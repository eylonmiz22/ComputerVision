
/* read the makefile to run the program */
