#include "symtab.h"
#include "ast.h"

IdNode::IdNode (char *name, int line) 
{
    myType t = getSymbol (name);
	if (t == UNKNOWN) { 
	    errorMsg ("line %d: variable %s is undefined\n", line, name);
		t = _INT;
    }
    _type = t;
	strcpy (this->_name, name); 
	_line = line;
}

BinaryOp::BinaryOp (enum op op, Exp *left, Exp *right, int line) 
{
	this->_op = op; 
	this->_left = left; 
	this->_right = right;
	_line = line;

	if ((this->_left->_type == _INT || this->_left->_type == _FLOAT) && (this->_right->_type == _INT || this->_right->_type == _FLOAT))
        	this->_type = this->_left->_type;
	else
		errorMsg ("line %d: left side and right side of BinaryOp have invalid types\n", _line);
}

AssignStmt::AssignStmt (IdNode *lhs, Exp *rhs, int line) 
   : Stmt ()  // call base class (super class) constructor
{
   _lhs = lhs; 
   _rhs = rhs; 
   _line = line; 

    if (! ((this->_lhs->_type == _INT || this->_lhs->_type == _FLOAT) && (this->_rhs->_type == _INT || this->_rhs->_type == _FLOAT)))
    	errorMsg ("line %d: left hand side and right hand side of assignment have invalid types\n", _line);

}

SwitchStmt::SwitchStmt (Exp *exp, Case *caselist, Stmt *default_stmt, int line) 
{
	_exp = exp; _caselist = caselist; _default_stmt = default_stmt; _line = line;
}

