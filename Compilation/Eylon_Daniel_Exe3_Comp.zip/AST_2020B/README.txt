Eylon Mizrahi 206125411
Daniel Ivkovich 316421262

Instructions:
	Please run the program on a linux OS by the makefile instructions.
	In the folder called "our_examples", there are test files for the requested missions that we chose. Please note this.
